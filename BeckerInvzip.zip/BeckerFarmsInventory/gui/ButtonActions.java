package gui;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class ButtonActions extends Application{
	
	public BorderPane getMainMenu() {
	HBox paneForButtons = new HBox(100);
	Button bt1 = new Button("Add an item to inventory");
    Button bt2 = new Button("View inventory");   
    Button bt3 = new Button("Edit an item's information");
    Button bt4 = new Button("Add a location");
    Button bt5 = new Button("View locations");
    Button bt6 = new Button("Add a type of item");
    Button bt7 = new Button("View types");
    paneForButtons.getChildren().addAll(bt1, bt2, bt3, bt4, bt5, bt6, bt7);
    paneForButtons.setAlignment(Pos.CENTER);
    paneForButtons.setStyle("-fx-border-color: brown");
	
	
	BorderPane pane = new BorderPane();
	pane.setCenter(paneForButtons);
	
	
	
	return pane;
	}
	
	
	
	/*
	public BorderPane getMainMenu()
	{
		BorderPane pane = new BorderPane();
		BorderPane paneForTextField = new BorderPane();
	    paneForTextField.setPadding(new Insets(5, 5, 5, 5)); 
	    paneForTextField.setStyle("-fx-border-color: green");
	    paneForTextField.setLeft(new Label("Enter your choice: "));
	    
	    TextField tf1 = new TextField("Item Name");
	    //String name, ArrayList <Location> LocationsAllowed, String type)
	    TextField tf2 = new TextField("Item Type");
	    TextField tf3 = new TextField("");
	    TextField tf4 = new TextField();
	   // tf1.setAlignment(Pos.BOTTOM_RIGHT);
	    //paneForTextField.setCenter(tf1);
	    paneForTextField.getChildren().addAll(tf1, tf2, tf3, tf4);
	    pane.setLeft(paneForTextField);
	    
	    return pane;
	}
	*/
	@Override // Override the start method in the Application class
	  public void start(Stage primaryStage) {
	    // Create a scene and place it in the stage
	    Scene scene = new Scene(getMainMenu(), 450, 200);
	    primaryStage.setTitle("Menu"); // Set the stage title
	    primaryStage.setScene(scene); // Place the scene in the stage
	    primaryStage.show(); // Display the stage
	    
	  }

	
	 public static void main(String[] args) {
		    launch(args);
		  }
		
}

