/*
 * Program name: Becker Farms Inventory
 * Author: Samantha Kolb
 * Date last updated: 5/17/2022
 * Synopsis: Create a program to keep track of items in inventory at the farm, this is for the GUI of the program
 */

package gui;


import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.text.*;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class MenuSetup extends Application {
	
	 public BorderPane AddItem()
		{
			 BorderPane pane = new BorderPane();
			BorderPane paneForTextField = new BorderPane();
		    paneForTextField.setPadding(new Insets(5, 5, 5, 5)); 
		    paneForTextField.setStyle("-fx-border-color: brown");
		    paneForTextField.setLeft(new Label("Enter a new message: "));
		    
		    //String name,  ArrayList <Location> locations, Type type, String size, String unit, int ID, int inv_num, int level1, int level2, int level3)
		    TextField tf1 = new TextField();
		    //String name, ArrayList <Location> LocationsAllowed, String type)
		    TextField tf2 = new TextField();
		    TextField tf3 = new TextField();
		    TextField tf4 = new TextField();
		    
		    
		    Label label1 = new Label("Item Name");
		    Label label2 = new Label("Item Type");
		    Label label3 = new Label("Item size");
		    Label label4 = new Label("Item unit");
		    Label label5 = new Label("Item Inventory number");
		    
		    
		   // tf1.setAlignment(Pos.BOTTOM_RIGHT);
		    //paneForTextField.setCenter(tf1);
		    paneForTextField.getChildren().addAll(tf1, tf2, tf3, tf4);
		    pane.setLeft(paneForTextField);
		    
		    
		    
		    tf1.setOnAction(e -> tf1.getText());
		    
		    tf2.setOnAction(e -> tf2.getText());
		    
			HBox paneForButtons = new HBox(20);
			Button bt1 = new Button("Submit");
		    Button bt2 = new Button("View inventory");   
		    Button bt3 = new Button("Edit an item's information");
		    Button bt4 = new Button("Add a location");
		    Button bt5 = new Button("Add a type of item");
		    paneForButtons.getChildren().addAll(bt1, bt2, bt3, bt4, bt5);
		    paneForButtons.setAlignment(Pos.CENTER);
		    paneForButtons.setStyle("-fx-border-color: brown");
			
			
			    
			pane.setCenter(paneForTextField);
			
			return pane;
			
		}
		
		
	
	//"1. Add an item.\n2. Look at inventory\n3. Edit an item's information\n"
	 @Override // Override the start method in the Application class
	  public void start(Stage primaryStage) {
	    // Create a scene and place it in the stage
	    Scene scene = new Scene(AddItem(), 450, 200);
	    primaryStage.setTitle("Menu"); // Set the stage title
	    primaryStage.setScene(scene); // Place the scene in the stage
	    primaryStage.show(); // Display the stage
	    
	  }

	  /**
	   * The main method is only needed for the IDE with limited
	   * JavaFX support. Not needed for running from the command line.
	   */

	  public static void main(String[] args) {
	    launch(args);
	  }
	

	  
}
