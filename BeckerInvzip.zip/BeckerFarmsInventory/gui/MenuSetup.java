package gui;

/*
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class MenuSetup extends Application {
  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {
	  
	  Text text = new Text(40, 40, "Programming is fun");
	    Pane pane = new Pane(text);
	    
	    // Hold four buttons in an HBox
	    Button btUp = new Button("Up");
	    Button btDown = new Button("Down");
	    Button btLeft = new Button("Left");
	    Button btRight = new Button("Right");
	    HBox hBox = new HBox(btUp, btDown, btLeft, btRight);
	    hBox.setSpacing(10);
	    hBox.setAlignment(Pos.CENTER);
	    
	    BorderPane borderPane = new BorderPane(pane);
	    borderPane.setBottom(hBox);
	    
	    // Create and register the handler
	    btUp.setOnAction(new EventHandler<ActionEvent>() {
	      @Override // Override the handle method
	      public void handle(ActionEvent e) {
	        text.setY(text.getY() > 10 ? text.getY() - 5 : 10);
	      }
	    });

	    btDown.setOnAction(new EventHandler<ActionEvent>() {
	      @Override // Override the handle method
	      public void handle(ActionEvent e) {
	        text.setY(text.getY() < pane.getHeight() ? 
	          text.getY() + 5 : pane.getHeight());
	      }
	    });
	    
	    btLeft.setOnAction(new EventHandler<ActionEvent>() {
	      @Override // Override the handle method
	      public void handle(ActionEvent e) {
	        text.setX(text.getX() > 0 ? text.getX() - 5 : 0);
	      }
	    });
	    
	    btRight.setOnAction(new EventHandler<ActionEvent>() {
	      @Override // Override the handle method
	      public void handle(ActionEvent e) {
	        text.setX(text.getX() < pane.getWidth() - 100?
	          text.getX() + 5 : pane.getWidth() - 100);
	      }
	    });

	    // Create a scene and place it in the stage
	    Scene scene = new Scene(borderPane, 400, 350);
	    primaryStage.setTitle("AnonymousHandlerDemo"); // Set title
	    primaryStage.setScene(scene); // Place the scene in the stage
	    primaryStage.show(); // Display the stage
	  
	  
    // Create a pane and set its properties
    HBox pane = new HBox(10);
    pane.setAlignment(Pos.CENTER);
    Button btOK = new Button("OK");
    Button btCancel = new Button("Cancel");
    OKHandlerClass handler1 = new OKHandlerClass();
    btOK.setOnAction(handler1);
    CancelHandlerClass handler2 = new CancelHandlerClass();
    btCancel.setOnAction(handler2);
    pane.getChildren().addAll(btOK, btCancel);
    
    // Create a scene and place it in the stage
    Scene scene = new Scene(pane);
    primaryStage.setTitle("HandleEvent"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
  }

  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
/*
  public static void main(String[] args) {
    launch(args);
  }
} 
*/
/*
class OKHandlerClass implements EventHandler<ActionEvent> {
  @Override
  public void handle(ActionEvent e) {
    System.out.println("OK button clicked"); 
  }
}

class CancelHandlerClass implements EventHandler<ActionEvent> {
  @Override
  public void handle(ActionEvent e) {
    System.out.println("Cancel button clicked");
  }
}
*/


import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.text.*;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class MenuSetup extends Application {
	
	 public BorderPane AddItem()
		{
			 BorderPane pane = new BorderPane();
			BorderPane paneForTextField = new BorderPane();
		    paneForTextField.setPadding(new Insets(5, 5, 5, 5)); 
		    paneForTextField.setStyle("-fx-border-color: brown");
		    paneForTextField.setLeft(new Label("Enter a new message: "));
		    
		    //String name,  ArrayList <Location> locations, Type type, String size, String unit, int ID, int inv_num, int level1, int level2, int level3)
		    TextField tf1 = new TextField();
		    //String name, ArrayList <Location> LocationsAllowed, String type)
		    TextField tf2 = new TextField();
		    TextField tf3 = new TextField();
		    TextField tf4 = new TextField();
		    
		    
		    Label label1 = new Label("Item Name");
		    Label label2 = new Label("Item Type");
		    Label label3 = new Label("Item size");
		    Label label4 = new Label("Item unit");
		    Label label5 = new Label("Item Inventory number");
		    
		    
		   // tf1.setAlignment(Pos.BOTTOM_RIGHT);
		    //paneForTextField.setCenter(tf1);
		    paneForTextField.getChildren().addAll(tf1, tf2, tf3, tf4);
		    pane.setLeft(paneForTextField);
		    
		    
		    
		    tf1.setOnAction(e -> tf1.getText());
		    
		    tf2.setOnAction(e -> tf2.getText());
		    
			HBox paneForButtons = new HBox(20);
			Button bt1 = new Button("Submit");
		    Button bt2 = new Button("View inventory");   
		    Button bt3 = new Button("Edit an item's information");
		    Button bt4 = new Button("Add a location");
		    Button bt5 = new Button("Add a type of item");
		    paneForButtons.getChildren().addAll(bt1, bt2, bt3, bt4, bt5);
		    paneForButtons.setAlignment(Pos.CENTER);
		    paneForButtons.setStyle("-fx-border-color: brown");
			
			
			    
			pane.setCenter(paneForTextField);
			
			return pane;
			
		}
		
		
	
	//"1. Add an item.\n2. Look at inventory\n3. Edit an item's information\n"
	 @Override // Override the start method in the Application class
	  public void start(Stage primaryStage) {
	    // Create a scene and place it in the stage
	    Scene scene = new Scene(AddItem(), 450, 200);
	    primaryStage.setTitle("Menu"); // Set the stage title
	    primaryStage.setScene(scene); // Place the scene in the stage
	    primaryStage.show(); // Display the stage
	    
	  }

	  /**
	   * The main method is only needed for the IDE with limited
	   * JavaFX support. Not needed for running from the command line.
	   */

	  public static void main(String[] args) {
	    launch(args);
	  }
	

	  
}
