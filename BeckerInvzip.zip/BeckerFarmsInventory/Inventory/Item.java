/*
 * Program name: Becker Farms Inventory
 * Author: Samantha Kolb
 * Date last updated: 5/17/2022
 * Synopsis: Create a program to keep track of items in inventory at the farm, this is the item class
 * 
 */

package Inventory;


/*this class is for items, the private variables are:
	private String name;
	private ArrayList <Location> locations;
	private Type type;
	private String size;
	private int ID;
	private String unit;
	private int inv_num;
	private Date dateEntered;
	private int level1;
	private int level2;
	private int level3;
	
*/
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
//Item class to use for the items in inventory
public class Item {

	private String name;
	private ArrayList <Location> locations;
	private Type type;
	private String size;
	private int ID;
	private String unit;
	private int inv_num;
	private Date dateEntered;
	private int level1;
	private int level2;
	private int level3;
	
	Item()
	{
		this.name = " ";
		this.ID = 0;
		this.unit = " ";
		this.inv_num = 0;
		this.level1 = 0;
		this.level2 = 0;
		this.level3 = 0;
	}
	/*
	Item(String name,  ArrayList <Location> locations, Type type, String size, String unit, int ID, int inv_num, Date dateExpired, int level1, int level2, int level3)
	{
		this.name = name;
		this.locations = locations;
		this.type = type;
		this.size = size;
		this.ID = ID;
		this.unit = unit;
		this.inv_num = inv_num;
		this.dateExpired = dateExpired;
		this.level1 = level1;
		this.level2 = level2;
		this.level3 = level3;
		setDateEntered();
	}
	*/
	Item(String name,  ArrayList <Location> locations, Type type, String size, String unit, int ID, int inv_num, int level1, int level2, int level3)
	{
		this.name = name;
		this.locations = locations;
		this.type = type;
		this.size = size;
		this.ID = ID;
		this.unit = unit;
		this.inv_num = inv_num;
		this.level1 = level1;
		this.level2 = level2;
		this.level3 = level3;
		setDateEntered();
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	public void setLocation(ArrayList <Location> locations)
	{
		this.locations = locations;
	}
	public void setType(Type type)
	{
		this.type = type;
	}
	public void setID(int ID)
	{
		this.ID = ID;
	}
	public void setUnit(String unit)
	{
		this.unit = unit;
	}
	public void setInvNum(int inv_num)
	{
		this.inv_num = inv_num;
	}
	public void setDateEntered()
	{
		this.dateEntered = new Date();
	}
	
	public void setLevel1(int level1)
	{
		this.level1 = level1;
	}
	public void setLevel2(int level2)
	{
	
		if(level1 == -1)
		{
			int choice;
			System.out.println("Error: cannot set a level 2 for an item without a level 1.\n\tPress '1' if you "
					+ "want to set a different level 1\n\tPress '2' if you do not want to set either level 1 or level 2 (Exit)\n\tPress '3' if you want to set level 1 as " + level2 + " instead.");
			Scanner scanner = new Scanner(System.in);
			choice = scanner.nextInt();
			if(choice == 3)
			{
				setLevel1(level2);
				System.out.println("Press '1' if you want to enter a level 2 for " + name + " now\nPress '2' if you want to exit.");
				choice = scanner.nextInt();
			}
			if(choice == 1)
			{
				System.out.println("Enter the number you want to set level 1 for " + name);
				level2 = scanner.nextInt();
				this.level1 = level2;
			}
			if(choice == 2)
			{
				scanner.close();
				return;
			}
		
		scanner.close();
		}
		
	}
	public void setLevel3(int level3)
	{
		if(level1 == -1)
		{
			int choice;
			System.out.println("Error: cannot set a level 3 for an item without a level 1.\n\tPress '1' if you " + 
					           "want to set a different level 1\n\tPress '2' if you do not want to set either level 1 or level 2 (Exit) Press '3' if you want to set level 1 as " + level3 + 
					           " instead.");
			Scanner scanner = new Scanner(System.in);
			choice = scanner.nextInt();
			if(choice == 1)
			{
				System.out.println("Enter the number you want to set level 1 for " + name);
				level3 = scanner.nextInt();
				this.level1 = level3;
				System.out.println("Press '4' if you want to enter a level 2 for " + name + " \nPress '2' if you want to exit.");
				choice = scanner.nextInt();
			}
			if(choice == 3)
			{
				setLevel1(level3);
				System.out.println("Press '4' if you want to enter a level 2 for " + name + " \nPress '2' if you want to exit.");
				choice = scanner.nextInt();
			}
			if(choice == 4)
			{
				System.out.println("Enter the number you want to set level 2 for " + name);
				level3 = scanner.nextInt();
				this.level2 = level3;
				System.out.println("Press '5' if you want to enter a level 3 for " + name + " \nPress '2' if you want to exit.");
				choice = scanner.nextInt();
			}
			
			if(choice == 5)
			{
				System.out.println("Enter the number you want to set level 3 for " + name);
				level3 = scanner.nextInt();
				this.level3 = level3;
				
			}
			if(choice == 2)
			{
				scanner.close();
				return;
			}
		
		scanner.close();
		return;	
		}
		this.level3 = level3;
	}
	
	public String getName()
	{
		return name;
	}
	public String getLocations()
	{
		return " ";
	}
	public String getType()
	{
		return " ";
	}
	public int getID()
	{
		return ID;
	}
	public String getUnit()
	{
		return unit;
	}
	public int getInvNum()
	{
		return inv_num;
	}
	public String getDateEntered()
	{
		return dateEntered.toString();
	}

	public int getLevel1()
	{
		return level1;
	}
	public int getLevel2()
	{
		return level2;
	}
	public int getLevel3()
	{
		return level3;
	}
	public String toString()
	{
		/*
		 * private String name;
	private ArrayList <Location> locations;
	private Type type;
	private Size size;
	private int ID;
	private String unit;
	private int inv_num;
	private Date dateEntered;
	private Date dateExpired;
	private int level1;
	private int level2;
	private int level3;
		 */
		String s = "Item name: " + name + "\nLocations: ";
		for(int i = 0; i < locations.size(); i++)
		{
			s += locations.get(i) + " ";
		}
		s += type.toString() + "\nInventory: " + inv_num + "\nUnit: " + unit + "\nSize: " + size;
		/////////////////////////////////////////////////////////////////////////
		s += "Date Entered: " + dateEntered;
		
		if(level1 > -1)
		{
			s += "\nLevel 1: " +  level1;
		}
		if(level2 > -1)
		{
			s += "\nLevel 2: " +  level2;
		}
		if(level3 > -1)
		{
			s += "\nLevel 3: " +  level3;
		}
		return s;
	}
	public int compare(Item i)
	{
		if(this.ID == i.getID())
		{
			return 0;
		}
		else if(this.ID < i.getID())
		{
			return -1;
		}
		else if(this.ID > i.getID())
		{
			return 1;
		}
		else
			return 2;
	}
	public String getLevels()
	{
		String s = "";
		
		if(level3 != -1 && level2 != -1 && level1 != -1)
		{
			s += "Level 1: " + level1;
			s += "Level 2: " + level2;
			s += "Level 3: " + level3;
		}
		else if(level3 == -1 && level2 != -1 && level1 != -1)
		{
			s += "Level 1: " + level1;
			s += "Level 2: " + level2;
		}
		else if(level3 == -1 && level2 == -1 && level1 != -1)
		{
			s += "Level 1: " + level1;
		}
		else
			s += "Error: Couldn't access the level(s)";
			
		return s;
			
	}
	/*
	Item(String name,  ArrayList <Location> locations, Type type, String unit, int ID, int inv_num, Date dateExpired, int level1, int level2, int level3)
	{
		this.name = name;
		this.locations = locations;
		this.type = type;
		this.size = new Size("N/A", -1);
		this.ID = ID;
		this.unit = unit;
		this.inv_num = inv_num;
		this.dateExpired = dateExpired;
		this.level1 = level1;
		this.level2 = level2;
		this.level3 = level3;
		setDateEntered();
	}
	Item(String name,  ArrayList <Location> locations, Type type, Size size, String unit, int ID, int inv_num, int level1, int level2, int level3)
	{
		this.name = name;
		this.locations = locations;
		this.type = type;
		this.size = size;
		this.unit = unit;
		this.ID = ID;
		this.inv_num = inv_num;
		this.level1 = level1;
		this.level2 = level2;
		this.level3 = level3;
		setDateEntered();
	}
	Item(String name,  ArrayList <Location> locations, Type type, String unit, int ID, int inv_num, int level1, int level2, int level3)
	{
		this.name = name;
		this.locations = locations;
		this.type = type;
		this.size = new Size("N/A", -1);
		this.unit = unit;
		this.ID = ID;
		this.inv_num = inv_num;
		this.level1 = level1;
		this.level2 = level2;
		this.level3 = level3;
		setDateEntered();
	}
	Item(String name,  ArrayList <Location> locations, Type type, Size size, String unit, int ID, int inv_num, Date dateExpired, int level1, int level2)
	{
		this.name = name;
		this.locations = locations;
		this.type = type;
		this.size = size;
		this.unit = unit;
		this.ID = ID;
		this.inv_num = inv_num;
		this.dateExpired = dateExpired;
		this.level1 = level1;
		this.level2 = level2;
		this.level3 = -1;
		setDateEntered();
	}
	Item(String name,  ArrayList <Location> locations, Type type, String unit, int ID, int inv_num, Date dateExpired, int level1, int level2)
	{
		this.name = name;
		this.locations = locations;
		this.type = type;
		this.size = new Size("N/A", -1);
		this.unit = unit;
		this.ID = ID;
		this.inv_num = inv_num;
		this.dateExpired = dateExpired;
		this.level1 = level1;
		this.level2 = level2;
		this.level3 = -1;
		setDateEntered();
	}
	Item(String name,  ArrayList <Location> locations, Type type, Size size, String unit, int ID, int inv_num, Date dateExpired, int level1)
	{
		this.name = name;
		this.locations = locations;
		this.type = type;
		this.size = size;
		this.unit = unit;
		this.ID = ID;
		this.inv_num = inv_num;
		this.dateExpired = dateExpired;
		this.level1 = level1;
		this.level2 = -1;
		this.level3 = -1;
		setDateEntered();
	}
	Item(String name,  ArrayList <Location> locations, Type type, String unit, int ID, int inv_num, Date dateExpired, int level1)
	{
		this.name = name;
		this.locations = locations;
		this.type = type;
		this.size = new Size("N/A", -1);
		this.unit = unit;
		this.ID = ID;
		this.inv_num = inv_num;
		this.dateExpired = dateExpired;
		this.level1 = level1;
		this.level2 = -1;
		this.level3 = -1;
		setDateEntered();
	}
	Item(String name,  ArrayList <Location> locations, Type type, Size size, String unit, int ID, int inv_num, Date dateExpired)
	{
		this.name = name;
		this.locations = locations;
		this.type = type;
		this.size = size;
		this.unit = unit;
		this.ID = ID;
		this.inv_num = inv_num;
		this.dateExpired = dateExpired;
		this.level1 = -1;
		this.level2 = -1;
		this.level3 = -1;
		setDateEntered();
	}
	Item(String name,  ArrayList <Location> locations, Type type, String unit, int ID, int inv_num, Date dateExpired)
	{
		this.name = name;
		this.locations = locations;
		this.type = type;
		this.size = new Size("N/A", -1);
		this.unit = unit;
		this.ID = ID;
		this.inv_num = inv_num;
		this.dateExpired = dateExpired;
		this.level1 = -1;
		this.level2 = -1;
		this.level3 = -1;
		setDateEntered();
	}
	Item(String name,  ArrayList <Location> locations, Type type, Size size, String unit, int ID, int inv_num)
	{
		this.name = name;
		this.locations = locations;
		this.type = type;
		this.size = size;
		this.unit = unit;
		this.ID = ID;
		this.inv_num = inv_num;
		this.level1 = -1;
		this.level2 = -1;
		this.level3 = -1;
		setDateEntered();
	}
	Item(String name,  ArrayList <Location> locations, Type type, String unit, int ID, int inv_num)
	{
		this.name = name;
		this.locations = locations;
		this.type = type;
		this.size = new Size("N/A", -1);
		this.unit = unit;
		this.ID = ID;
		this.inv_num = inv_num;
		this.level1 = -1;
		this.level2 = -1;
		this.level3 = -1;
		setDateEntered();
	}
	Item(String name,  ArrayList <Location> locations, Type type, Size size, int ID, int inv_num)
	{
		this.name = name;
		this.locations = locations;
		this.type = type;
		this.size = size;
		this.unit = "single items";
		this.ID = ID;
		this.inv_num = inv_num;
		this.level1 = -1;
		this.level2 = -1;
		this.level3 = -1;
		setDateEntered();
	}
	Item(String name,  ArrayList <Location> locations, Type type, int ID, int inv_num)
	{
		this.name = name;
		this.locations = locations;
		this.type = type;
		this.size = new Size("N/A", -1);
		this.unit = "single items";
		this.ID = ID;
		this.inv_num = inv_num;
		this.level1 = -1;
		this.level2 = -1;
		this.level3 = -1;
		setDateEntered();
	}
	*/
	
}
