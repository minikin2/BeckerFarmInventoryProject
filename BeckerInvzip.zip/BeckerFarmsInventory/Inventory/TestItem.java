/*
 * Program name: Becker Farms Inventory
 * Author: Samantha Kolb
 * Date last updated: 5/17/2022
 * Synopsis: Create a program to keep track of items in inventory at the farm, this class tests the item class which is where most of the information is at
 * 
 */

package Inventory;

import java.util.ArrayList;


import java.util.Scanner;


public class TestItem {

	public static ArrayList<Item> items;
	
	public static void main(String [] args)
	{
		/*
		    try (
		      // Create an output stream to the file
		      FileOutputStream output = new FileOutputStream("Items.dtxt");
		    ) {
		      // Output values to the file
		      for (int i = 1; i <= 10; i++)
		        output.write(i);
		    }

		    try (
		      // Create an input stream for the file
		      FileInputStream input = new FileInputStream("Items.txt");
		    ) {
		      // Read values from the file
		      int value;
		      while ((value = input.read()) != -1)
		        System.out.print(value + " ");
		    }
		  */

		setItems();
		System.out.println(getItems());
		
			
		}

	
	public static ArrayList<Item> setItems () 
	{
		/*
		try (
			      // Create an output stream to the file
			      FileOutputStream output = new FileOutputStream("Items.dat");
			    ) {
			      // Output values to the file
			      for (int i = 1; i <= 10; i++)
			        output.write(items.get(i).toString());
			    }
/*
			    try (
			      // Create an input stream for the file
			      FileInputStream input = new FileInputStream("Items.dat");
			    ) 
			    */
		String name = "0", unit, size;
		Type type;
		int id, inv_num, level1, level2, level3;
		ArrayList <Location> locAllowed = new ArrayList<>();
		Scanner scanner = new Scanner(System.in);
		while(name != "-1") {
			 unit = "single pk";
			 id = items.size();
			 inv_num = 0;
			 level1 = 0; 
			 level2 = 0;
			 level3 = 0;
			System.out.println("Enter the name of the item you want to add or enter -1 to exit.");
			name = scanner.nextLine();
			if(name != "-1")
			{
				
				/*
				 * String name, ArrayList <Location> LocationsAllowed, String type)
				 */
				System.out.println("Please enter a type for the item (enter the name of the type or enter 0 to enter a new type");
				type = TestType.getType();
				System.out.println("Enter the size of the item");
				size = scanner.nextLine();
				System.out.println("Enter the unit used to count it.");
				unit = scanner.nextLine();
				System.out.println("Enter the number of inventory of items currently");
				inv_num = scanner.nextInt();
				
				
				locAllowed = TestLocation.setLocationsAllowed();
				System.out.println("Enter the level 1 for the item");
				level1 = scanner.nextInt();
				System.out.println("Enter the level 2 for the item");
				level2 = scanner.nextInt();
				System.out.println("Enter the level 3 for the item");
				level3 = scanner.nextInt();
				items.add(new Item (name, locAllowed, type, size, unit, id, inv_num, level1, level2, level3));
				
			}
			
		}
		scanner.close();
		return items;
	}
	
	
	public static void addItem(Item i)
	{
		items.add(i);
		/*
		String name = "0";
		Scanner scanner = new Scanner(System.in);
		String type = "N/A", typeD = "None";
		//loc = new ArrayList<>();
		System.out.println("Enter the name of the location you want to add or enter -1 to exit.");
		name = scanner.next();
		if(name != "-1")
		{
			System.out.println("Enter the type of location it is.");
			type = scanner.next();
			System.out.println("Enter the description of the type of location, or enter 0 if you don't want to have a description");
			typeD = scanner.next();
			if(typeD == "0")
			{
				loc.add(new Location(name, type, "None"));
			}
			loc.add(new Location(name, type, typeD));
		}
		
		scanner.close();
		*/
	}

	public static ArrayList<Item> getItemsArray()
	{
		return items;
	}

	public static String getItems()
	{
		//return loc.toString();
		String s = "";
		for(int i = 0; i < items.size(); i++)
		{
			s += items.getClass().toString();
		}
		return s;
		
	}
}


