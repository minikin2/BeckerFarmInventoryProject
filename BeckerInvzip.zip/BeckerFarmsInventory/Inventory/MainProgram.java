package Inventory;

public class MainProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}
