package Inventory;

import java.util.ArrayList;
import java.util.Scanner;

//testing the Location class
public class TestLocation {
	
	public static ArrayList<Location> loc;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//variables to hold the location name, type, and type descriptio
	
		setLocations();
		System.out.println(getLocations());
		
	}
	
	
	public static ArrayList<Location> setLocations()
	{
		String name = "0";
		Scanner scanner = new Scanner(System.in);
		String type = "N/A", typeD = "None";
		//loc = new ArrayList<>();
		System.out.println("Enter the name of the location you want to add or enter -1 to exit.");
		name = scanner.nextLine();
		while(name != "-1") {
			System.out.println("Enter the name of the location you want to add or enter -1 to exit.");
			name = scanner.nextLine();
			if(name != "-1")
			{
				System.out.println("Enter the type of location it is.");
				type = scanner.nextLine();
				//System.out.println("Enter the description of the type of location, or enter 0 if you don't want to have a description");
				//typeD = scanner.nextLine();
				if(typeD == "0")
				{
					loc.add(new Location(name, type, "None"));
				}
				else {
					loc.add(new Location(name, type, typeD));
				}
			}
			
		}
		scanner.close();
		return loc;
	}
	public static void addLocation(Location l)
	{
		loc.add(l);
		/*
		String name = "0";
		Scanner scanner = new Scanner(System.in);
		String type = "N/A", typeD = "None";
		//loc = new ArrayList<>();
		System.out.println("Enter the name of the location you want to add or enter -1 to exit.");
		name = scanner.next();
		if(name != "-1")
		{
			System.out.println("Enter the type of location it is.");
			type = scanner.next();
			System.out.println("Enter the description of the type of location, or enter 0 if you don't want to have a description");
			typeD = scanner.next();
			if(typeD == "0")
			{
				loc.add(new Location(name, type, "None"));
			}
			loc.add(new Location(name, type, typeD));
		}
		
		scanner.close();
		*/
	}
public static ArrayList<Location> setLocationsAllowed()
	{
		String name = "0";
		Scanner scanner = new Scanner(System.in);
		String type = "N/A", typeD = "None";
		boolean isGood = false; 
		ArrayList<Location> locA = new ArrayList<>();
		while(name != "-1") {
			System.out.println("Enter the name of the location you want to allow or enter -1 to exit.");
			name = scanner.nextLine();
			for(int i = 0; i < loc.size() || isGood; i++)
			{
				if(name == loc.get(i).getName())
				{
					isGood = true;
					locA.add(loc.get(i));
					
				}
			}
			if(!isGood)
			{
				System.out.println("That is not a valid location, please try again");
				continue;
			}
			
		}
		scanner.close();
		return locA;
	}
	public static ArrayList<Location> getLocationsArray()
	{
		return loc;
	}

	public static String getLocations()
	{
		//return loc.toString();
		String s = "";
		for(int i = 0; i < loc.size(); i++)
		{
			s += loc.getClass().toString();
		}
		return s;
		
	}
}
