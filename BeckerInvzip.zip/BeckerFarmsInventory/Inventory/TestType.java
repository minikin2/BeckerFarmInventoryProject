package Inventory;

import java.util.ArrayList;
import java.util.Scanner;

/*
 * class to test the Type class
 */
public class TestType {

	public static ArrayList<Type> types;
	public static void main(String[] args) {
		// 
		

	/*
		Location l = new Location("Freezer 1", "Freezer", "something");
		//ArrayList<Location> loc = getLocationsArray();   
		ArrayList <Location> loc = new ArrayList<>();
		loc.add(l);
		Type a = new Type("Meat", loc, "Beef");
		Type b = new Type("Milk", loc, "something", "Plastic", "Whole");
		Type c = new Type("Egg", loc, "something", "Cartons");
		
		System.out.println("A: " + a.getName() + " "+ a.getLocationsAllowed() + " " + a.getDescription() + " " + a.getContainer() + " " + a.getType() + " " + a.toString());
		*/
		
		setTypes();
		System.out.println(getTypes());
		
	}
	
	public static Type getType()
	{
		String s = "";
		int choice;
		for(int i = 0; i < types.size(); i++)
		{
			System.out.println(i + types.getClass().toString());
		}
		Scanner scanner = new Scanner(System.in);
		choice = scanner.nextInt();
		while(choice > types.size() || choice < 0)
		{
			System.out.println("Please enter a valid choice");
			choice = scanner.nextInt();
		}
		return types.get(choice);
		
	}
	
	public static ArrayList<Type> setTypes()
	{
		String name = "0";
		Scanner scanner = new Scanner(System.in);
		String type = "N/A", container = "N/A", description = "None";
		ArrayList<Location> locAllowed = new ArrayList<>();
		while(name != "-1")
		{
			System.out.println("Enter the name of the type you want to add or enter -1 to exit.");
			name = scanner.nextLine();
			if(name != "-1")
			{
				System.out.println("Enter the type it is.(Example: Meat can be beef, pork, etc.)");
				type = scanner.nextLine();
				locAllowed = TestLocation.setLocationsAllowed();
				System.out.println("Enter the container for the type, or enter -1 if it has no container type");
				container = scanner.nextLine();
				System.out.println("Enter the description for the type, or enter -1 if you don't want to");
				description = scanner.nextLine();
				if(container == "-1")
				{
					container = "N/A";
				}
				if(description == "-1")
				{
					description = "N/A";
				}
				types.add(new Type(name, locAllowed, container, description, type));
			}
			
		}
		scanner.close();
		return types;
	}
	public static void addType(Type t)
	{
		/*
		String name = "0";
		Scanner scanner = new Scanner(System.in);
		String type = "N/A", container = "N/A", description = "None";
		ArrayList<Location> locAllowed = new ArrayList<>();
		System.out.println("Enter the name of the type you want to add or enter -1 to exit.");
		name = scanner.next();
		if(name != "-1")
		{
			System.out.println("Enter the type it is.(Example: Meat can be beef, pork, etc.)");
			type = scanner.next();
			locAllowed = TestLocation.setLocationsAllowed();
			System.out.println("Enter the container for the type, or enter -1 if it has no container type");
			container = scanner.next();
			System.out.println("Enter the description for the type, or enter -1 if you don't want to");
			description = scanner.next();
			if(container == "-1")
			{
				container = "N/A";
			}
			if(description == "-1")
			{
				description = "N/A";
			}
			types.add(new Type(name, locAllowed, container, description, type));
		}
			
		scanner.close();
		*/
		types.add(t);
	}


	public static ArrayList<Type> getTypesArray()
	{
		return types;
	}
	public static String getTypes()
	{
		String s = "";
		for(int i = 0; i < types.size(); i++)
		{
			s += types.getClass().toString();
		}
		return s;
	}

}
