/*
 * Program name: Becker Farms Inventory
 * Author: Samantha Kolb
 * Date last updated: 5/17/2022
 * Synopsis: Create a program to keep track of items in inventory at the farm, this class is the type class
 * 
 */

package Inventory;

import java.util.ArrayList;

public class Type {

	private String name;
	private ArrayList <Location> LocationsAllowed;
	private String container;
	private String description;
	private String type;
	
	Type()
	{
		this.name = " ";
		this.container = " ";
		this.description = " ";
		this.type = " ";
		
	}
	Type(String name, ArrayList <Location> LocationsAllowed, String type)
	{
		this.name = name;
		this.LocationsAllowed = LocationsAllowed;
		this.container = "N/A";
		this.description = "None";
		this.type = type;
	} 
	Type(String name, ArrayList <Location> LocationsAllowed, String description, String type)
	{
		this.name = name;
		this.LocationsAllowed = LocationsAllowed;
		this.container = "N/A";
		this.description = description;
		this.type = type;
	}
	Type(String name, ArrayList <Location> LocationsAllowed, String container, String description, String type)
	{
		this.name = name;
		this.LocationsAllowed = LocationsAllowed;
		this.container = container;
		this.description = description;
		this.type = type;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public void setLocationsAllowed(ArrayList <Location> LocationsAllowed)
	{
		this.LocationsAllowed = LocationsAllowed;
	}
	public void setContainer(String container)
	{
		this.container = container;
	}
	public void setDescription(String description)
	{
		this.description = description;
	}
	public void setType(String type)
	{
		this.type = type;
	}
	public String getName()
	{
		return name;
	}
	public String getLocationsAllowed()
	{
		String s = "";
		for(int i = 0; i < LocationsAllowed.size(); i++)
		{
			s += LocationsAllowed.get(i).toString() + " ";
		}
		return s;
	}
	public String getContainer()
	{
		return container;
	}
	public String getDescription()
	{
		return description;
	}
	public String getType()
	{
		return type;
	}
	public String toString()
	{
		return "Name: " + name + "Locations Allowed: " + LocationsAllowed.toString() + "Container Type: " + container + "Description: " + description + "Type: " + type;
	}
	
}
