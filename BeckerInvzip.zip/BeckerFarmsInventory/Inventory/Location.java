package Inventory;

public class Location {
	private String name;
	private String type;
	private String type_description;
	
	Location()
	{
		this.name = "N/A";
		this.type = "N/A";
		this.type_description = "N/A";
	}
	Location(String name, String type, String typeD)
	{
		this.name = name;
		this.type = type;
		this.type_description = typeD;
	}
	public void setName(String n)
	{
		name = n;
	}
	public void setType(String t)
	{
		type = t;
	}
	public void setTypeDescription(String typeD)
	{
		type_description = typeD;
	}
	public String getName()
	{
		return name;
	}
	public String getType()
	{
		return type;
	}
	public String getTypeDescription()
	{
		return type_description;
	}
	public String toString()
	{
		return "Location: " + name + "\nType: " + type + "\nDescription: " + type_description;
	}
}
